[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=40&pause=1000&color=0000FF&center=true&vCenter=true&width=815&height=60&lines=💲+▭+▬+▭+▬+▭+▬+▭+▬+▭+▬+▭+🎭)](https://git.io/typing-svg) 

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=100&pause=900&color=1BAFBAFF&center=true&width=1100&height=150&lines=THE-+HUB+BOT" alt="Typing SVG" /></a>
  </p>



<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=DAA520&center=true&width=910&height=100&lines=THE+HUB+TEAM+;KEEP+USING+THE+HUB+BOT" alt="Typing SVG" /></a>
  </p>
 
  
<a href="https://whatsapp.com/channel/0029Vb3zzYJ9xVJk0Y65c81W">
 <img alt="THE-HUB" height="600" src="https://files.catbox.moe/gg76op.jpg"></a>
 

# ❤️ ғᴏʀᴋ ᴍʏ ʀᴇᴘᴏ
- <a align="center"><a href="https://github.com/drapterlagas/THE-HUB-BOT/fork"> <img src="https://img.shields.io/badge/FORK%20REPO-colorless?style=for-the-badge&logo=porsche" width="220" height="38.45"/></a></p>

# 🤍 ɢᴇᴛ ᴘᴀɪʀ ᴄᴏᴅᴇ
</a></p>
- <a href="https://pair-nector-session.onrender.com"><img title="TAP FOR SESSION ID" src="https://img.shields.io/badge/LOG IN FOR SESSION ID-h?color=pink&style=for-the-badge&logo=porsche&logoColor=pink" width="240" height="38.45"/></a></p>

# 💝 ᴄʀᴇᴀᴛᴇ ʜᴇʀᴏᴋᴜ

</a></p>
- <a href='https://signup.heroku.com/' target="_silver"><img alt='Heroku' src='https://img.shields.io/badge/-𝐂𝐑𝐄𝐀𝐓𝐄 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 𝐍𝐎𝐖-rgb(224, 255, 255)?style=for-the-badge&logo=ferrari&logoColor=pink' width="240" height="38.45"/></a>



# 🧡 Render Deployment 
- <a align="center"><a href="https://dashboard.render.com/web/new"> <img src="https://img.shields.io/badge/RENDER%20DEPLOYMENT-red?style=for-the-badge&logo=nike" width="220" height="38.45"/></a></p>


## 💖 CONTACT ME
[![Whatsapp contact](https://img.shields.io/badge/Contact-%20ⓃⒺCⓉOR🍯-25D366?style=for-the-badge&logo=whatsapp)](https://wa.me/+254725474072)

