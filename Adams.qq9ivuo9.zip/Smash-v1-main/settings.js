const settings = {
  packname: 'LOFTXMD',
  author: '‎',
  botName: "*𝐒𝐌𝐀𝐒𝐇-𝐕𝟏* 💥",
  botOwner: 'Sir Loft', // Your name
  ownerNumber: '255778018545', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "private",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.6",
};

module.exports = settings;
