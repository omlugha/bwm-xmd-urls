let handler = async (m, { reply }) => {
// pedo
reply("bug menu is under maintenance, will be replaced with a function in the next update")
}
handler.command = ["bugmenu"]
module.exports = handler