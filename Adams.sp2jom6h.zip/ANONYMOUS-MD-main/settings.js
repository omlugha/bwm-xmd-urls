const fs = require('fs')
const chalk = require('chalk')

//SETTINGS OWNER\\
global.ownernumber = "263789745277"
global.ownername = "KEITH TECH"
global.fother = "KEITH-XMD"

//SETTINGS BOT\\
global.namabot = "KEITH XMD"
global.baileys = "@whiskeysocket/baileys"
global.botNumber = "263789745277"
global.version = "5.0.1"
global.packname = "Created BY Keith"
global.botname = "Keith Xmd multi device ʙᴏᴛ"
global.author = "Keith"
global.foother = "Powered By Keith"

//SETTINGS MEDIA \\
global.website = "https://youtube.com/Keith-tech57"
global.thumbnail = "http://keith-cdn.vercel.app/file/uf9eue.jpg"
global.yt = "https://youtube.com/Keith-tech57"

global.welcome = true
global.self = false
global.statusview = true
// ANTICALL SETTING \\
global.antcimage = "http://keith-cdn.vercel.app/file/uf9eue.jpg"
global.anticall = true
global.anticallMessage = "🚫 CALL BLOCKED\n> Hello! This is ANONYMOUS-MD Assistant.\n> Calls are not allowed on this number. Please message instead.\n\n> _*Powered by Keith*_"

global.antidelete = 'same'; // or 'inbox' or 'off'
global.timezone = 'Africa/Harare'; // optional
//SETTINGS MESSAGE\\
global.mess = {
    error: 'Oops bro, there\'s an error issue here',
    done: 'Doneee bro',
    success: 'Successful bro',
    admin: 'Admins Only Bro, What are you doing? 🧐🤨',
    botAdmin: 'The Bot Isn\'t an Admin Yet, LOL 😂🤭',
    creator: 'Hey, what are you doing?\nThis feature is for the Owner only, LOL 😂🤭',
    owner: 'Only for the owner, bro',
    group: 'This feature is for Groups Only 🤭',
    private: 'Only for Private Chat with the Bot 🤭',
    wait: 'Hold on bro, we\'re processing it first'
}

function emoticonMatcher(string, emot) {
    let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
}

module.exports = {
    SESSION_MAX_AGE: 1800000,
    CLEAN_INTERVAL: 120000,
    emoticonMatcher
};

global.closeMsgInterval = 30; 
global.backMsgInterval = 2;