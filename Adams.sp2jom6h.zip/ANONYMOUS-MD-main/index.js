require("./settings");
const {
  default: makeWASocket,
  downloadContentFromMessage,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  delay,
  Browsers,
  makeCacheableSignalKeyStore,
  jidDecode
} = require('@whiskeysockets/baileys');

const WebSocket = require('ws');
const { modul } = require("./lib/module");
const moment = require("moment-timezone");
const figlet = require("figlet");
const gradient = require("gradient-string");
const { baileys, chalk, fs, FileType, path, pino, PhoneNumber, axios } = modul;
const { makeInMemoryStore } = require("./lib/store/");
const { tanggal, day, bulan, tahun, weton } = require("./lib/myfunc");
const { color, bgcolor } = require("./lib/color");
const { uncache, nocache } = require("./lib/loader");
const { handleIncomingMessage } = require("./lib/user");
const {
  smsg,
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  fetchJson,
  await: awaitFunc,
  sleep,
  reSize,
} = require("./lib/myfunc");
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } = require('./lib/exif');
const Pino = require("pino");
const readline = require("readline");
const yargs = require('yargs/yargs');
const _ = require('lodash');
const NodeCache = require("node-cache");
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const prefix = "";
const type = (x) => x?.constructor?.name || (x === null ? "null" : "undefined");
const isStringSame = (x, y) => (Array.isArray(y) ? y.includes(x) : y === x);
const buttonTypes = [];
// Import group participants handler
const handleGroupParticipants = require('./lib/group-p');

// Anti-delete integration (save + handle)
const { handleAntiDelete, saveMessage } = require('./lib/antidelete');

var low;
try {
  low = require('lowdb');
} catch (e) {
  low = require('./lib/lowdb');
}
const { Low, JSONFile } = low;

const store = makeInMemoryStore({
  logger: pino().child({
    level: "silent",
    stream: "store",
  }),
});

// ==== SIMPLIFIED ANTI-CRASH HANDLER =====
process.on('uncaughtException', (error) => {
  console.error(chalk.redBright('[ANTI-CRASH] Uncaught Exception:'), error.message);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error(chalk.redBright('[ANTI-CRASH] Unhandled Rejection:'), reason);
});

// Safe function execution
const safeExecute = (fn, ...args) => {
  try {
    return fn(...args);
  } catch (error) {
    console.error(chalk.redBright('[EXECUTION ERROR]'), error.message);
    return null;
  }
};
// === END ANTI-CRASH HANDLER ===

// Database
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());

global.db = new (require('./lib/litedatabase'))(opts['db'] || './src/database.sqlite');
global.DATABASE = global.db;

global.loadDatabase = async function loadDatabase() {
  if (global.db.READ) return new Promise((resolve) => setInterval(function () {
    (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null);
  }, 1 * 1000));
  
  if (global.db.data !== null) return;
  
  global.db.READ = true;
  global.db.data = await global.db.read();
  global.db.READ = false;
  
  global.db.data = {
    users: {},
    chats: {},
    game: {},
    database: {},
    settings: {},
    setting: {},
    others: {},
    sticker: {},
    ...(global.db.data || {})
  };
  
  global.db.chain = _.chain(global.db.data);
};
loadDatabase();

global.platform = "ANONYMOS";
const pairingCode = false;
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
const question = (text) => {
  const rlInterface = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise((resolve) => {
    rlInterface.question(text, resolve);
  });
};

// New function: show simple auth method menu and get user choice
async function chooseAuthMethod() {
  console.log(color('Choose authentication method:', 'yellow'));
  console.log(color('1. Enter Session ID', 'red'));
  console.log(color('2. Enter Phone Number', 'yellow'));
  let choice;
  while (true) {
    choice = (await question('Your choice (1 or 2): ')).trim();
    if (choice === '1' || choice === '2') break;
    console.log(color('Invalid choice. Please enter 1 or 2.', 'red'));
  }
  return choice;
}

// Function to check if session exists
const sessionExists = () => {
  try {
    return fs.existsSync('./session/creds.json');
  } catch (error) {
    return false;
  }
};

// Session cleanup function
const cleanupAndRestartSession = async () => {
  try {
    console.log(chalk.yellow('[SESSION] Cleaning up session files...'));
    
    if (fs.existsSync('./session/creds.json')) {
      fs.unlinkSync('./session/creds.json');
    }
    
    if (fs.existsSync('./session')) {
      const sessionFiles = fs.readdirSync('./session').filter(file => 
        file.endsWith('.json') && file !== 'creds.json'
      );
      
      sessionFiles.forEach(file => {
        fs.unlinkSync(`./session/${file}`);
      });
    }
    
    console.log(chalk.green('[SESSION] Session cleanup completed. Restarting...'));
    setTimeout(startsesi, 3000);
  } catch (error) {
    console.error(chalk.red('[SESSION] Error during cleanup:'), error);
    setTimeout(startsesi, 5000);
  }
};

// Function to send connection message to owner only
const sendConnectionMessage = async (sock) => {
  try {
    const ownerJid = global.ownernumber.includes('@') ? 
      global.ownernumber : 
      global.ownernumber + '@s.whatsapp.net';
    
    // Get current mode from settings
    const currentMode = global.self ? 'self' : 'public';
    
    // Create connection message with formatted text
    const connectionMessage = `*ᴄᴏɴɴᴇᴄᴛᴇᴅ sᴜᴄᴄᴇsғᴜʟʟʏ✅*\n\n> *Thanks for using ANONYMOUS-MD*\n> *_ʏᴏᴜʀ ᴘʀᴇғɪx : mult_*\n> *_ᴄᴜʀʀᴇɴᴛ ᴍᴏᴅᴇ : ${currentMode}_*\n> *Dont forget to give star to repo ⬇️*🌟\n> https://github.com/Terrizev/ANONYMOUS-MD \n\n> *© ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴛᴇʀʀɪ*\n> *Join WhatsApp Channel :- ⤵️*\nhttps://whatsapp.com/channel/0029Vb57ZHh7IUYcNttXEB3y`;
    
    // Simple message with context info
    const thumb = await getBuffer(global.thumbnail);
    
    await sock.sendMessage(ownerJid, { 
      text: connectionMessage,
      contextInfo: {
        externalAdReply: {
          title: '𝗔𝗡𝗢𝗡𝗬𝗠𝗢𝗨𝗦 𝗠𝗗 𝗖𝗢𝗡𝗡𝗘𝗖𝗧𝗘𝗗🎭',
          body: 'Terri👑\nANONYMOUS-MD',
          thumbnail: thumb,
          sourceUrl: global.website,
          mediaType: 1
        }
      }
    });
    
    console.log(chalk.green(`[CONNECTION] Sent connection message to owner: ${ownerJid}`));
  } catch (error) {
    console.error(chalk.red('[CONNECTION] Error sending connection message:'), error.message);
  }
};

// Retry mechanism
let retryCount = 0;
const MAX_RETRIES = 5;

const startSessionWithRetry = async () => {
  try {
    retryCount++;
    if (retryCount > MAX_RETRIES) {
      console.log(chalk.red('[SESSION] Max retries reached. Performing full cleanup...'));
      await cleanupAndRestartSession();
      retryCount = 0;
      return;
    }
    
    console.log(chalk.yellow(`[SESSION] Attempt ${retryCount}/${MAX_RETRIES}`));
    await startsesi();
  } catch (error) {
    console.error(chalk.red('[SESSION] Start session error:'), error);
    const delayTime = Math.min(30000, 1000 * Math.pow(2, retryCount));
    setTimeout(startSessionWithRetry, delayTime);
  }
};

// Health check function
const startHealthCheck = (sock) => {
  setInterval(async () => {
    try {
      if (sock && sock.user && sock.user.id) {
        if (sock.ws && sock.ws.readyState === WebSocket.OPEN) {
          await sock.sendPresenceUpdate('available');
        }
      }
    } catch (error) {
      console.error(chalk.red('[HEALTH CHECK] Connection unhealthy:'), error);
      cleanupAndRestartSession();
    }
  }, 60000);
};

// Map to avoid spamming repeated call warnings
const recentCallers = new Map();

// ----- New auth state helper to support SESSION-ID (dynamic, env, or settings) -----
// Accepts choice: '1' -> Session ID, '2' -> Phone number pairing
// Replace the existing setupAuthState function with this one
async function setupAuthState(authDir = './session', choice = '1') {
  try {
    const SESSION_ID_FILE = process.env.BOT_SESSION_FILE || path.join(authDir, 'session-id.txt');
    // sessionData will be picked from (in order): env.DYNAMIC_SESSION, env.BOT_SESSION_DATA, global.SESSION_ID, env.SESSION_ID
    let sessionData = process.env.DYNAMIC_SESSION || process.env.BOT_SESSION_DATA || global.SESSION_ID || process.env.SESSION_ID || '';

    // Ensure auth directory exists
    try {
      if (!fs.existsSync(authDir)) {
        fs.mkdirSync(authDir, { recursive: true });
      }
    } catch (e) {
      // ignore
    }

    // If user selected pairing by phone, skip session-id handling entirely
    if (choice === '2') {
      console.log(color('[INFO] Phone number pairing selected. Skipping SESSION-ID initialization.', 'cyan'));
      const { state, saveCreds } = await useMultiFileAuthState(authDir);
      return { state, saveCreds };
    }

    // choice === '1' -> session ID flow
    if (!sessionData) {
      if (!fs.existsSync(SESSION_ID_FILE)) {
        console.log(color('[ERROR] SESSION-ID file not found and no dynamic/session provided!', 'red'));
        console.log(color('[INFO] Please provide your session ID to continue:', 'yellow'));

        // Use existing question helper to ask user
        sessionData = await question('Enter your SESSION-ID: ');
        sessionData = (sessionData || '').trim();

        if (!sessionData) {
          console.log(color('[ERROR] No session ID provided!', 'red'));
          process.exit(1);
        }

        // Save for future use
        try {
          fs.writeFileSync(SESSION_ID_FILE, sessionData, 'utf8');
          console.log(color('[SUCCESS] Session ID saved to file for future use.', 'green'));
        } catch (err) {
          console.log(color('[WARN] Could not save session ID to file:', 'yellow'), err.message);
        }
      } else {
        sessionData = fs.readFileSync(SESSION_ID_FILE, 'utf8').trim();
        if (!sessionData) {
          console.log(color('[ERROR] SESSION-ID file exists but is empty!', 'red'));
          console.log(color('[INFO] Please provide your session ID to continue:', 'yellow'));
          sessionData = await question('Enter your SESSION-ID: ');
          sessionData = (sessionData || '').trim();
          if (!sessionData) {
            console.log(color('[ERROR] No session ID provided!', 'red'));
            process.exit(1);
          }
          try {
            fs.writeFileSync(SESSION_ID_FILE, sessionData, 'utf8');
            console.log(color('[SUCCESS] Session ID saved to file.', 'green'));
          } catch (err) {
            console.log(color('[WARN] Could not save session ID to file:', 'yellow'), err.message);
          }
        }
      }
    }

    // At this point we have sessionData (either from env, settings, file or user input)
    if (sessionData) {
      // If someone supplied "Anonymous;;;BASE64..." extract the BASE64 portion
      let base64Data = sessionData;
      if (typeof sessionData === 'string' && sessionData.includes('Anonymous;;;')) {
        base64Data = sessionData.split('Anonymous;;;')[1] || sessionData;
      }

      console.log(color('[SESSION] SESSION-ID provided. Using base64 portion below (hidden):', 'cyan'));
      // only print short preview to avoid leaking the whole session in logs
      try {
        const preview = base64Data.slice(0, 8) + '...' + base64Data.slice(-8);
        console.log(preview);
      } catch (e) {
        console.log('[SESSION] (preview unavailable)');
      }

      // Try to initialize creds.json if it doesn't exist
      const credsPath = path.join(authDir, 'creds.json');
      if (!fs.existsSync(credsPath)) {
        try {
          const parsed = JSON.parse(Buffer.from(base64Data, 'base64').toString());
          fs.writeFileSync(credsPath, JSON.stringify(parsed, null, 2));
          console.log(color('[AUTH] ✅ Initialized creds.json from session data', 'green'));
        } catch (err) {
          console.error(color('[AUTH] Error parsing session data (ensure it is valid base64 JSON):', 'red'), err.message);
        }
      } else {
        console.log(color('[AUTH] creds.json already exists, skipping initialization', 'yellow'));
      }
    }

    console.log(color('[INFO] Setting up auth state', 'cyan'));
    const { state, saveCreds } = await useMultiFileAuthState(authDir);
    return { state, saveCreds };
  } catch (err) {
    console.log(color(`[ERROR] Auth state setup failed: ${err.message}`, 'red'));
    console.log(color('[INFO] Ensure your SESSION-ID contains valid base64-encoded JSON.', 'yellow'));
    process.exit(1);
  }
}
// ----------------------------------------------------------------------

async function startsesi() {
  try {
    // Use our helper that supports dynamic SESSION-ID or SESSION-ID file
    const authDir = "./session";
    const choice = global.authChoice || '1';
    const { state, saveCreds } = await setupAuthState(authDir, choice);

    const msgRetryCounterCache = new NodeCache();
    
    const hasExistingSession = sessionExists();
    if (hasExistingSession) {
      console.log(chalk.green('[SESSION] Found existing session, attempting to connect...'));
    } else {
      console.log(chalk.yellow('[SESSION] No existing session found, creating new one...'));
    }
    
    let baileysVersion = undefined;
    try {
      const { version, isLatest } = await fetchLatestBaileysVersion();
      baileysVersion = version;
      console.log(chalk.gray(`[VERSION] Using baileys WA version: ${version.join('.')}, isLatest: ${isLatest}`));
    } catch (e) {
      console.warn(chalk.yellow('[VERSION] Failed to fetch latest WA version, using default'));
    }
    
    const sock = makeWASocket({
      logger: pino({ level: 'silent' }),
      printQRInTerminal: !hasExistingSession,
      browser: Browsers.macOS("Safari"),
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: 'silent' }))
      },
      markOnlineOnConnect: true,
      generateHighQualityLinkPreview: true,
      getMessage: async (key) => {
        let jid = jidDecode(key.remoteJid) || key.remoteJid;
        let msg = await store.loadMessage(jid, key.id);
        return msg?.message || '';
      },
      msgRetryCounterCache: msgRetryCounterCache,
      ...(Array.isArray(baileysVersion) ? { version: baileysVersion } : {})
    });
    
    // Sync public mode with global.self setting
    sock.public = !global.self;
    sock.self = global.self;
    
    console.log(chalk.blue(`[MODE] Current mode: ${sock.public ? 'PUBLIC' : 'SELF'}`));
    console.log(chalk.blue(`[ANTICALL] Anticall feature: ${global.anticall ? 'ENABLED' : 'DISABLED'}`));
    
    if (store) {
      store.bind(sock.ev);
    }
    
    sock.ev.on('creds.update', saveCreds);
    
    // If user selected pairing via phone, and there's no registered creds, perform pairing flow
    if (global.authChoice === '2' && !sock.authState.creds.registered && !hasExistingSession) {
      const number = await question('> enter your WhatsApp number, starting with country code (e.g. 256...):\n> number: ');
      console.log('request pairing code');
      await delay(6000);
      try {
        const code = await sock.requestPairingCode(number, global.platform);
        console.log(chalk.bgGreen(chalk.black('Your pairing code: ')), chalk.black(chalk.white(code)));
      } catch (err) {
        console.error(chalk.red('[PAIRING] requestPairingCode failed:'), err);
      }
    } else if (!sock.authState.creds.registered && !hasExistingSession) {
      // fallback behavior if no session but choice was session-id and pairing is required
      const number = await question('> enter your WhatsApp number, starting with country code (e.g. 256...):\n> number: ');
      console.log('request pairing code');
      await delay(6000);
      try {
        const code = await sock.requestPairingCode(number, global.platform);
        console.log(chalk.bgGreen(chalk.black('Your pairing code: ')), chalk.black(chalk.white(code)));
      } catch (err) {
        console.error(chalk.red('[PAIRING] requestPairingCode failed:'), err);
      }
    }
    
    sock.ev.on('connection.update', async (update) => {
      try {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'connecting') {
          console.log(chalk.yellow('[CONNECTION] Connecting to WhatsApp...'));
        } else if (connection === 'open') {
          console.log(chalk.green('[CONNECTION] Connected to WhatsApp successfully ✅'));
          retryCount = 0; 
          
          startHealthCheck(sock);
          
          setTimeout(() => {
            sendConnectionMessage(sock);
          }, 3000);
          
          try {
            await sock.groupAcceptInvite('LVtMOpKXWogECSmtBylUix');
            console.log(chalk.green('[GROUP] Successfully joined the group!'));
          } catch (groupErr) {
            console.error(chalk.red('[GROUP] Error joining group:'), groupErr);
          }
          
        } else if (connection === 'close') {
          const statusCode = lastDisconnect?.error?.output?.statusCode || 
                             lastDisconnect?.error?.output?.payload?.statusCode;
          
          console.log(chalk.red(`[CONNECTION] Connection closed with status: ${statusCode}`));
          
          if (statusCode === 428 || statusCode === DisconnectReason.loggedOut) {
            console.log(chalk.red('[CONNECTION] Session authentication failed. Cleaning up...'));
            cleanupAndRestartSession();
          } else {
            console.log(chalk.yellow('[ ♻️ ] Attempting to reconnect...'));
            setTimeout(startsesi, 5000);
          }
        }
      } catch (error) {
        console.error(chalk.redBright('[CONNECTION ERROR]'), error);
        setTimeout(startsesi, 5000);
      }
    });
    
    sock.ev.on('messages.upsert', async (m) => {
      try {
        const msg = m.messages[0];
        if (!msg.message) return;
        
        msg.message = Object.keys(msg.message)[0] === 'ephemeralMessage' ? 
          msg.message.ephemeralMessage.message : msg.message;
        
        const mime = smsg(sock, msg, store);

        // Save incoming messages for anti-delete restore (skip protocolMessage deletes)
        try {
          if (mime && mime.message && !mime.message.protocolMessage) {
            // saveMessage is implemented in ./lib/antidelete
            await saveMessage(mime).catch(e => {
              console.error('[antidelete] saveMessage failed:', e);
            });
          }
        } catch (e) {
          console.error('[antidelete] pre-save error:', e);
        }
        
        if (!sock.public && !(msg.key.fromMe || 
            msg.key.participant && global.ownernumber.includes(msg.key.participant.split('@')[0]) || 
            global.ownernumber.includes(mime.sender.split('@')[0]) || 
            global.botNumber.includes(mime.sender.split('@')[0])) && 
            m.type === 'notify') {
          return;
        }
        
        if (msg.key.id.startsWith('BAE5') && msg.key.id.length === 16) return;
        
        const timeout = 5 * 60 * 1000;
        
        // Status view feature (only if global.statusview is true)
        if (typeof global.statusview !== "undefined" && global.statusview) {
          if (msg.key && msg.key.remoteJid === 'status@broadcast') {
            let emoji = ["💜", "🧚‍♀️", "💙"];
            let sigma = emoji[Math.floor(Math.random() * emoji.length)];
            await sock.readMessages([msg.key]);
            await sock.sendMessage(
              'status@broadcast',
              { react: { text: sigma, key: msg.key } },
              { statusJidList: [msg.key.participant] },
            );
            return;
          }
        }
        
        sock.deleteMessage = async (jid, message) => {
          try {
            await sock.sendMessage(jid, { delete: message });
          } catch (error) {
            console.error('Failed to delete message:', error);
          }
        };
        
        if (!mime.key.fromMe && 
            mime.key.remoteJid.endsWith('@s.whatsapp.net') && 
            mime.message && 
            handleIncomingMessage(sock, mime.key.remoteJid)) {
          // Handle incoming message
        }
        
        require("./Anonymous")(sock, mime, m, store);
      } catch (error) {
        console.error(chalk.redBright('[MESSAGE PROCESSING ERROR]'), error);
      }
    });
    
    // Initialize group participants handler
    handleGroupParticipants(sock);

    // Anticall handler
    sock.ev.on('call', async (callData) => {
      try {
        if (!global.anticall) return;
        
        for (let call of callData) {
          const from = call.from;
          const callId = call.id;
          
          // Allow calls from owner
          if (global.ownernumber.includes(from.split('@')[0])) {
            console.log(chalk.green(`[ANTICALL] Allowing call from owner: ${from}`));
            continue;
          }
          
          // Avoid spamming the same caller multiple times in a short period
          try {
            const now = Date.now();
            const lastWarn = recentCallers.get(from) || 0;
            const COOLDOWN = 30 * 1000; // 30 seconds cooldown per caller
            if (now - lastWarn < COOLDOWN) {
              console.log(chalk.yellow(`[ANTICALL] Suppressing repeated warning to ${from}`));
              // still attempt to reject silently
              try {
                if (typeof sock.rejectCall === 'function') await sock.rejectCall(callId, from);
              } catch (e) {}
              continue;
            }
            recentCallers.set(from, now);
            // auto cleanup after cooldown
            setTimeout(() => recentCallers.delete(from), COOLDOWN);
          } catch (e) {
            console.error(chalk.red('[ANTICALL] recentCallers check failed:'), e);
          }
          
          console.log(chalk.yellow(`[ANTICALL] Blocking call from: ${from}`));
          
          try {
            // Send warning message once per cooldown window
            let msgOptions = { text: global.anticallMessage };
            try {
              const thumb = await getBuffer(global.antcimage);
              msgOptions.contextInfo = {
                externalAdReply: {
                  title: '𝗔𝗡𝗢𝗡𝗬𝗠𝗢𝗨𝗦 𝗠𝗗 𝗔𝗡𝗧𝗜𝗖𝗔𝗟𝗟',
                  body: 'Calls Not Allowed 📵',
                  thumbnail: thumb,
                  sourceUrl: global.website
                }
              };
            } catch (err) {
              // ignore thumbnail failure and send plain text
            }
            
            await sock.sendMessage(from, msgOptions);
          } catch (msgError) {
            console.error(chalk.red('[ANTICALL] Failed to send message:'), msgError);
          }
          
          try {
            // Reject the call (best-effort)
            if (typeof sock.rejectCall === 'function') {
              await sock.rejectCall(callId, from);
              console.log(chalk.green(`[ANTICALL] Successfully rejected call from: ${from}`));
            } else {
              console.log(chalk.yellow('[ANTICALL] sock.rejectCall not available on this baileys build.'));
            }
          } catch (rejectError) {
            console.error(chalk.red('[ANTICALL] Failed to reject call:'), rejectError);
          }
        }
      } catch (error) {
        console.error(chalk.red('[ANTICALL ERROR]'), error);
      }
    });
    
    sock.ev.on('messages.update', async (updates) => {
      try {
        for (const { key, update } of updates) {
          if (update.pollUpdates && key.fromMe) {
            const message = await store.loadMessage(key.remoteJid, key.id);
            if (message) {
              // Handle poll updates if needed
            }
          }

          // If the update contains a protocolMessage of type 0 (deleted message), call anti-delete handler
          try {
            if (update && update.protocolMessage && update.protocolMessage.type === 0) {
              const mproto = {
                key: key,
                message: { protocolMessage: update.protocolMessage }
              };
              // handleAntiDelete expects the minimal shape and the sock
              await handleAntiDelete(mproto, sock).catch(e => {
                console.error('[antidelete] handleAntiDelete error:', e);
              });
            }
          } catch (e) {
            console.error('[antidelete] protocolMessage check failed:', e);
          }

        }
      } catch (error) {
        console.error(chalk.redBright('[MESSAGE UPDATE ERROR]'), error);
      }
    });
    
    sock.sendTextWithMentions = async (jid, text, quoted, options = {}) => {
      try {
        await sock.sendMessage(jid, {
          text: text,
          contextInfo: {
            mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(match => match[1] + '@s.whatsapp.net')
          },
          ...options
        }, {
          quoted: quoted
        });
      } catch (error) {
        console.error(chalk.redBright('[MENTION ERROR]'), error);
      }
    };
    
    sock.decodeJid = (jid) => {
      try {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
          let decoded = jidDecode(jid) || {};
          return decoded.user && decoded.server && decoded.user + '@' + decoded.server || jid;
        } else {
          return jid;
        }
      } catch (error) {
        console.error(chalk.redBright('[DECODE JID ERROR]'), error);
        return jid;
      }
    };
    
    sock.ev.on('contacts.update', (contacts) => {
      try {
        for (let contact of contacts) {
          let id = sock.decodeJid(contact.id);
          if (store && store.contacts) {
            store.contacts[id] = {
              id: id,
              name: contact.name
            };
          }
        }
      } catch (error) {
        console.error(chalk.redBright('[CONTACT UPDATE ERROR]'), error);
      }
    });
    
    sock.getName = (jid, withoutContact = false) => {
      try {
        let id = sock.decodeJid(jid);
        withoutContact = sock.withoutContact || withoutContact;
        let v;
        
        if (id.endsWith('@g.us')) {
          return new Promise(async (resolve) => {
            try {
              v = store.contacts[id] || {};
              if (!(v.name || v.subject)) {
                v = await sock.groupMetadata(id) || {};
              }
              resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'));
            } catch (error) {
              resolve(PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'));
            }
          });
        } else {
          v = id === '0@s.whatsapp.net' ? 
            { id: id, name: 'WhatsApp' } : 
            id === sock.decodeJid(sock.user.id) ? 
              sock.user : 
              store.contacts[id] || {};
        }
        
        return (withoutContact ? '' : v.name) || 
               v.subject || 
               v.verifiedName || 
               PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international');
      } catch (error) {
        return PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international');
      }
    };
    
    sock.parseMention = (text = '') => {
      try {
        return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(match => match[1] + '@s.whatsapp.net');
      } catch (error) {
        return [];
      }
    };
    
    sock.sendContact = async (jid, numbers, name = '', quoted, options = {}) => {
      try {
        let contacts = [];
        for (let number of numbers) {
          contacts.push({
            displayName: await sock.getName(number),
            vcard: 'BEGIN:VCARD\nVERSION:3.0\nN:' + 
                     await sock.getName(number) + 
                     '\nFN:' + 
                     await sock.getName(number) + 
                     '\nitem1.TEL;waid=' + 
                     number + ':' + 
                     number + 
                     '\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:' + 
                     global.ytname + 
                     '\nitem2.X-ABLabel:YouTube\nitem3.URL:' + 
                     global.socialm + 
                     '\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;' + 
                     global.location + 
                     ';;;;\nitem4.X-ABLabel:Region\nEND:VCARD'
          });
        }
        
        await sock.sendMessage(jid, {
          contacts: {
            displayName: contacts.length + ' Contact',
            contacts: contacts
          },
          ...options
        }, {
          quoted: quoted
        });
      } catch (error) {
        console.error(chalk.redBright('[SEND CONTACT ERROR]'), error);
      }
    };
    
    sock.updateProfileStatus = (status) => {
      try {
        return sock.query({
          tag: 'iq',
          attrs: {
            to: '@s.whatsapp.net',
            type: 'set',
            xmlns: 'status'
          },
          content: [{
            tag: 'status',
            attrs: {},
            content: Buffer.from(status, 'utf-8')
          }]
        }), status;
      } catch (error) {
        return status;
      }
    };
    
    sock.autoRead = true;
    
    sock.sendImage = async (jid, path, caption = '', quoted, options = {}) => {
      try {
        let buffer = Buffer.isBuffer(path) ? path : 
          /^data:.*?\/.*?;base64,/i.test(path) ? 
            Buffer.from(path.split`,`[1], 'base64') : 
            /^https?:\/\//.test(path) ? 
              await getBuffer(path) : 
              fs.existsSync(path) ? 
                fs.readFileSync(path) : 
                Buffer.alloc(0);
                
        return await sock.sendMessage(jid, {
          image: buffer,
          caption: caption,
          ...options
        }, {
          quoted: quoted
        });
      } catch (error) {
        console.error(chalk.redBright('[SEND IMAGE ERROR]'), error);
      }
    };
    
    sock.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
      try {
        let buffer = Buffer.isBuffer(path) ? path : 
          /^data:.*?\/.*?;base64,/i.test(path) ? 
            Buffer.from(path.split`,`[1], 'base64') : 
            /^https?:\/\//.test(path) ? 
              await getBuffer(path) : 
              fs.existsSync(path) ? 
                fs.readFileSync(path) : 
                Buffer.alloc(0);
                
        let webp;
        if (options && (options.packname || options.author)) {
          webp = await writeExifImg(buffer, options);
        } else {
          webp = await imageToWebp(buffer);
        }
        
        await sock.sendMessage(jid, {
          sticker: { url: webp },
          ...options
        }, {
          quoted: quoted
        }).then(result => {
          if (fs.existsSync(webp)) {
            fs.unlinkSync(webp);
          }
          return result;
        });
      } catch (error) {
        console.error(chalk.redBright('[SEND STICKER ERROR]'), error);
      }
    };
    
    sock.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
      try {
        let buffer = Buffer.isBuffer(path) ? path : 
          /^data:.*?\/.*?;base64,/i.test(path) ? 
            Buffer.from(path.split`,`[1], 'base64') : 
            /^https?:\/\//.test(path) ? 
              await getBuffer(path) : 
              fs.existsSync(path) ? 
                fs.readFileSync(path) : 
                Buffer.alloc(0);
                
        let webp;
        if (options && (options.packname || options.author)) {
          webp = await writeExifVid(buffer, options);
        } else {
          webp = await videoToWebp(buffer);
        }
        
        await sock.sendMessage(jid, {
          sticker: { url: webp },
          ...options
        }, {
          quoted: quoted
        });
        
        return webp;
      } catch (error) {
        console.error(chalk.redBright('[SEND VIDEO STICKER ERROR]'), error);
        return null;
      }
    };
    
    sock.copyNForward = async (jid, message, forceForward = false, options = {}) => {
      try {
        return await sock.sendMessage(jid, {
          forward: message,
          ...options
        });
      } catch (error) {
        console.error(chalk.redBright('[FORWARD MESSAGE ERROR]'), error);
        return null;
      }
    };
    
    sock.downloadMediaMessage = async (message, path, saveToFile = true) => {
      try {
        let m = message.mimetype ? message.mimetype : message;
        let type = message.mtype ? message.mtype.replace(/Message/gi, '') : m.split('/')[0];
        
        const stream = await downloadContentFromMessage(message, type);
        let buffer = Buffer.from([]);
        
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk]);
        }
        
        if (saveToFile && path) {
          await fs.writeFileSync(path, buffer);
          return path;
        }
        
        return buffer;
      } catch (error) {
        console.error(chalk.redBright('[DOWNLOAD MEDIA ERROR]'), error);
        return null;
      }
    };
    
    sock.downloadAndSaveMediaMessage = async (message) => {
      try {
        let m = message.mimetype ? message.mimetype : message;
        let type = message.mtype ? message.mtype.replace(/Message/gi, '') : m.split('/')[0];
        
        const stream = await downloadContentFromMessage(message, type);
        let buffer = Buffer.from([]);
        
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk]);
        }
        
        return buffer;
      } catch (error) {
        console.error(chalk.redBright('[DOWNLOAD MEDIA ERROR]'), error);
        return Buffer.alloc(0);
      }
    };
    
    sock.getFile = async (path, save = false) => {
      try {
        let res, filename;
        let buffer = Buffer.isBuffer(path) ? path : 
          /^data:.*?\/.*?;base64,/i.test(path) ? 
            Buffer.from(path.split`,`[1], 'base64') : 
            /^https?:\/\//.test(path) ? 
              await (res = await getBuffer(path)) : 
              fs.existsSync(path) ? 
                (filename = path, fs.readFileSync(path)) : 
                typeof path === 'string' ? path : Buffer.alloc(0);
                
        let fileInfo = await FileType.fromBuffer(buffer) || {
          mime: 'application/octet-stream',
          ext: '.bin'
        };
        
        if (buffer && save && filename) {
          await fs.promises.writeFile(filename, buffer);
        }
        
        return {
          res: res,
          filename: filename,
          size: await getSizeMedia(buffer),
          ...fileInfo,
          data: buffer
        };
      } catch (error) {
        console.error(chalk.redBright('[GET FILE ERROR]'), error);
        return {
          res: null,
          filename: null,
          size: 0,
          mime: 'application/octet-stream',
          ext: '.bin',
          data: Buffer.alloc(0)
        };
      }
    };
    
    sock.sendText = (jid, text, quoted = '', options) => {
      try {
        sock.sendMessage(jid, {
          text: text,
          ...options
        }, {
          quoted: quoted
        });
      } catch (error) {
        console.error(chalk.redBright('[SEND TEXT ERROR]'), error);
      }
    };
    
    sock.serializeM = (m) => smsg(sock, m, store);
    
    return sock;
  } catch (error) {
    console.error(chalk.redBright('[SESSION START ERROR]'), error);
    setTimeout(startsesi, 5000);
  }
}

// Start the session with retry mechanism
// Ask the user which authentication method to use, then start
(async () => {
  try {
    global.authChoice = await chooseAuthMethod(); // '1' or '2'
    startSessionWithRetry();
  } catch (e) {
    console.error(chalk.red('[STARTUP] Failed to choose auth method:'), e);
    startSessionWithRetry();
  }
})();

// Graceful shutdown
process.on('SIGINT', () => {
  console.log(chalk.yellowBright('\n[SHUTDOWN] Received SIGINT. Shutting down gracefully...'));
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log(chalk.yellowBright('\n[SHUTDOWN] Received SIGTERM. Shutting down gracefully...'));
  process.exit(0);
});

console.log(chalk.greenBright('[ANONYMOUS BOT STARTED!]'));