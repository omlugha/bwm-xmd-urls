(function (TipkIhNJPENnUOTI$cwUXDpb, dcCO_zDWnAXlTuf) {
  const BAUISOfQuGOQYVapPcwqdsLqV = TipkIhNJPENnUOTI$cwUXDpb();
  while (true) {
    try {
      const iBGHcGZEoRUYJOnsPSsmK = Math.max(-parseFloat(M_ibCjrdFa(0x171)) / (Number(0x1) * 0xf3b + -0xd * parseInt(0x7a) + -parseInt(0x242) * 0x4), -parseFloat(M_ibCjrdFa(0x179)) / (-parseInt(0x10) * -parseInt(0x244) + -parseInt(0x409) + parseInt(0x5) * -parseInt(0x671))) + parseFloat(M_ibCjrdFa(0x12b)) / (-6224 + parseInt(-0x153f) + parseInt(0x2d92)) * (parseFloat(M_ibCjrdFa(0x14a)) / (Math.max(-0x48b, -0x48b) * Math.ceil(-parseInt(0x4)) + Number(parseInt(0x3)) * Math.trunc(0x85d) + Math.floor(-0x2b3f))) + Math.trunc(-parseFloat(M_ibCjrdFa(0x14d)) / (-0x3 * Math.max(-parseInt(0x752), -0x752) + parseInt(0x1bdd) + -parseInt(0x31ce))) * Number(parseFloat(M_ibCjrdFa(0x131)) / (-parseInt(0x7) * Math.trunc(parseInt(0x435)) + parseInt(0x2a5) + -parseInt(0x194) * Math.trunc(-0x11))) + -parseFloat(M_ibCjrdFa(0x16b)) / (Math.trunc(-0x17cd) * parseInt(0x1) + -parseInt(0xdf6) + 9674) * (parseFloat(M_ibCjrdFa(0x14e)) / (parseInt(-0x1064) + Math.max(parseInt(0x1174), parseInt(0x1174)) + parseFloat(-0x108))) + Math.max(-parseFloat(M_ibCjrdFa(0x124)) / (parseFloat(parseInt(0xc7b)) + parseFloat(parseInt(0x1600)) + parseInt(0x2272) * -0x1), -parseFloat(M_ibCjrdFa(0x155)) / (Math.ceil(-parseInt(0x6)) * parseInt(0x8d) + 0x493 * parseInt(0x6) + -parseInt(0x181a))) + parseInt(-parseFloat(M_ibCjrdFa(0x13e)) / (0x1 * Number(parseInt(0xcf7)) + 0x1e30 + -11036)) + parseFloat(M_ibCjrdFa(0x143)) / (-6563 + parseInt(0x19af));
      if (iBGHcGZEoRUYJOnsPSsmK === dcCO_zDWnAXlTuf) {
        break;
      } else {
        BAUISOfQuGOQYVapPcwqdsLqV.push(BAUISOfQuGOQYVapPcwqdsLqV.shift());
      }
    } catch (onVgx_GzdTvk) {
      BAUISOfQuGOQYVapPcwqdsLqV.push(BAUISOfQuGOQYVapPcwqdsLqV.shift());
    }
  }
})(ui_pl$hE, parseInt(0x3106c) + Math.floor(-0x1100b) * Math.floor(parseInt(0x3)) + parseInt(0x24771));
import OiN_qtplNYIi from 'fs';
import VsMHdeht_AIpVLXcQ from 'fs/promises';
import oIS$QIjP from 'path';
import bPdOVPWsx$I_pxzxSQPyS from 'express';
import 'axios';
import atLChKDX from 'chalk';
import 'moment-timezone';
import { fileURLToPath } from 'url';
import { createServer } from 'http';
function M_ibCjrdFa(huLovPzgNf, djB_kDx$QrZfnLXXOPkdxft) {
  const npOiNqtplNYIiDVsMHdehtA = ui_pl$hE();
  M_ibCjrdFa = function (pVLXcQgoIS_QIjPKbP_dO, PWsxIp$xzxSQPySbyjm_FKhatL) {
    pVLXcQgoIS_QIjPKbP_dO = pVLXcQgoIS_QIjPKbP_dO - 292;
    let hKDXMeTxQVxZB_x_bs = npOiNqtplNYIiDVsMHdehtA[pVLXcQgoIS_QIjPKbP_dO];
    if (M_ibCjrdFa.vHWCvm === undefined) {
      const zNKZPyJkf$_ZJ = function (cvHZCxZn) {
        let SWNhtRA$_zvjEfJkDGh = parseFloat(-0xed) * Math.floor(-0x8) + -parseInt(0x14aa) + Math.max(-0x83, -0x83) * -0x1f & Number(0x1aab) + parseInt(0x81e) + Math.max(parseInt(0x1), parseInt(0x1)) * -0x21ca;
        let lLW_b$euhYzGJHzvu = new Uint8Array(cvHZCxZn.match(/.{1,2}/g).map(prpMEOVHDAgQiFCrhwsWi => parseInt(prpMEOVHDAgQiFCrhwsWi, 0x1 * Math.floor(0xa51) + Math.ceil(0xf29) * parseFloat(parseInt(0x2)) + -parseInt(0x2893))));
        let jpa$xp = lLW_b$euhYzGJHzvu.map(PRE_tVambfiTazrlrH => PRE_tVambfiTazrlrH ^ SWNhtRA$_zvjEfJkDGh);
        let mfGZKkZLpDOAmabQVpQ = new TextDecoder();
        let TWuCCvpzouAzyJoyzh_v$xqSnM = mfGZKkZLpDOAmabQVpQ.decode(jpa$xp);
        return TWuCCvpzouAzyJoyzh_v$xqSnM;
      };
      M_ibCjrdFa.ydMLXZ = zNKZPyJkf$_ZJ;
      huLovPzgNf = arguments;
      M_ibCjrdFa.vHWCvm = true;
    }
    const IcXTqYMcPgKr__NkLKm = npOiNqtplNYIiDVsMHdehtA[Math.floor(-0x2606) + parseInt(0x35) * -0x29 + Math.floor(parseInt(0x2e83))];
    const hmaUz_oBxkFS$fsauDIW = pVLXcQgoIS_QIjPKbP_dO + IcXTqYMcPgKr__NkLKm;
    const HNytUMXLexxz$BmQdcKShLtAAp = huLovPzgNf[hmaUz_oBxkFS$fsauDIW];
    if (!HNytUMXLexxz$BmQdcKShLtAAp) {
      if (M_ibCjrdFa.TfRrYO === undefined) {
        M_ibCjrdFa.TfRrYO = true;
      }
      hKDXMeTxQVxZB_x_bs = M_ibCjrdFa.ydMLXZ(hKDXMeTxQVxZB_x_bs);
      huLovPzgNf[hmaUz_oBxkFS$fsauDIW] = hKDXMeTxQVxZB_x_bs;
    } else {
      hKDXMeTxQVxZB_x_bs = HNytUMXLexxz$BmQdcKShLtAAp;
    }
    return hKDXMeTxQVxZB_x_bs;
  };
  return M_ibCjrdFa(huLovPzgNf, djB_kDx$QrZfnLXXOPkdxft);
}
import { File } from 'megajs';
import gKrNkLKmGhmaU$zoBxkFSf from 'pino';
import { makeWASocket, DisconnectReason, fetchLatestBaileysVersion, useMultiFileAuthState, Browsers } from '@whiskeysockets/baileys';
import auDIW_ZHNytUM from './config.cjs';
import { Handler, Callupdate, GroupUpdate } from './Hans/HansTz/index.js';
import LexxzBmQdcKShLtAApr$zNKZPy from './lib/autoreact.cjs';
import './Hans/HansTech/hansoi.js';
const {
  doReact,
  emojis
} = LexxzBmQdcKShLtAApr$zNKZPy;
const __filename = fileURLToPath(import.meta[M_ibCjrdFa(0x15e)]);
const __dirname = oIS$QIjP[M_ibCjrdFa(0x165)](__filename);
const logger = gKrNkLKmGhmaU$zoBxkFSf({
  'level': M_ibCjrdFa(0x139)
});
const tempDir = oIS$QIjP[M_ibCjrdFa(0x178)](__dirname, M_ibCjrdFa(0x162));
const PORT = process[M_ibCjrdFa(0x12a)][M_ibCjrdFa(0x157)] || Math.ceil(parseInt(0x15c2)) + parseInt(parseInt(0x75)) * parseInt(0x1) + Math.trunc(-parseInt(0x2b)) * parseInt(0x6d);
let initialConnection = true;
function ui_pl$hE() {
  const MzKdOivpJ = ['aaabc2d9e9fec1ca', 'a3efe9dcd3f9cb', 'f4ebfef5', 'd3dad5c8b6c3d6df', 'f8faf7f7', 'f3efefebe8a1b4b4ecf3faefe8faebebb5f8f4f6b4f8f3faf5f5fef7b4ababa9a2cdfae8f2d4f4c9a8f9f9ceecaefacdafead9a8aa', '7a2f037a2f147a2f3a7a2f1c511b7a2f1c7a2f1ebb51025114bbd3faf5e8b6c3f6ff', 'eee8fe', 'afaea8aeababd9ded8c8c1ef', 'e8effaefeee8d8f4fffe', 'cbd4c9cf', 'f7f2e8effef5', 'eee8fee9', 'f0fee2', 'fde9f4f6cec9d7', 'd3faf5e8cfe1bd', 'f6fee8e8fafcfe', 'eee9f7', 'e9feebf7faf8fe', 'daeeeff4c9fefaf8efbbdee9e9f4e9a1', 'e9fefafffff2e9', 'effef6eb', 'f9f7eefe', 'fee9e9f4e9', 'fff2e9f5faf6fe', 'fce9f4eeebb6ebfae9eff2f8f2ebfaf5efe8b5eeebfffaeffe', 'ddf2e9fefdf4e3', 'f8f4f5f5fef8eff2f4f5b5eeebfffaeffe', 'f3efefebe8a1b4b4fdf2f7fee8b5f8faeff9f4e3b5f6f4feb4f6f5a3a8aef7b5f1ebfc', 'f4eeefebeeef', 'a9acadacafaed2eee9c3d2ef', 'ece9f2effeddf2f7fe', 'f7fef5fceff3', 'f8f7f4e8fe', 'fde9f4f6d6fe', 'f8f4f5f8faef', 'a3afa3aaa3eef2edcfd5cd', 'fcfeef', '91a5bb79071e790f18b171072a7a2f007a2f1b7a2f007a2f0771072aa1b1bb7a2f14522f51045231522f7a2f1cbbbdbb71072a7a2f007a2f1b510251047a2f1c91790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a', '790220742314bbc9fef8f4f5f5fef8effeffb5', 'f2f5fffee3b5f3eff6f7', 'b4e8fee8e8f2f4f5e8b4f8e9feffe8b5f1e8f4f5', 'f7f4fcfcfeffd4eeef', 'f1f4f2f5', 'aaada2ada8adecdfd6cbf7c1', 'f8e9feffe8b5eeebfffaeffe', 'afaba3aaaeabc1f6ccc2e3ef', 'c8dec8c8d2d4d5c4d2df', 'f3efefebe8a1b4b4f6fefcfab5f5e1b4fdf2f7feb4', 'f7f4fc', 'e8fef5ffd6fee8e8fafcfe', '6b04170bbbc8fee9edfee9bbf7f2e8effef5f2f5fcbbf4f5bbebf4e9efbb', 'fef5ed', 'a8a2a9aca2a8caffe8fcdfc8', 'd8f4f5f5fef8effeffbbeff4bbccf3faefe8daebebbb791428bbdef5f1f4e2b5b5b5b5b5b5b5b5', '91a5bb6b041534790f18b17a2f03511b7a2f1c71072b5231e3a1b1bb', '790617bbd8f4f5f5fef8eff2f4f5bbf8f7f4e8feffb5bbc9fef8f4f5f5fef8eff2f5fcb5b5b5', 'e8fef5ffddf2f7fe', 'dacecfd4c4c9dedad8cf', 'adaea9afaea9fce9c2cacdd0', 'aaa9aba8ada8a8aea9aba3acabacaba9a8a8dbf5feece8f7feefeffee9', 'fdf7f4f4e9', 'e9feff', 'f6fee8e8fafcfee8', 'eef5f7f2f5f0', '91790f1a790f1a781b15bbd3faf5e8b6c3f6ffbb710535522f52317a2f0052317a2f1b510452317a2f397a2f1c7a2f1ebb781b14790f1a790f1a91790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a790f1a91a5bb79013a790f18b151027a2f147a2f00bb522f7a2f1b7a2f167a2f1ca1b1bbd3faf5e8b6c3f6ff91a5bb6b040a0a790f18b17a2f147a2f3a522f7a2f1c511ba1b1bbd3faf5e8b6c3f6ff91a5bb790102742314790f18b17a2f167a2f147a2f1e7a2f1ca1b1bb', 'd3faf5e8', 'e8f2f7fef5ef', 'f6f0fff2e9', 'e9faf5fff4f6', 'cbc9deddd2c3', 'ebeef9f7f2f8', 'a9aaa9abaca3a2d0d6d8e2efe1', 'f6fee8e8fafcfee8b5eeebe8fee9ef', 'e8effaeff2f8', 'fee3f2ef', 'fff4ecf5f7f4faff', 'acaba3a8aea3a3f4ded8caebf7', 'fce9fefef5', 'ebeee8f3', 'b4e8fee8e8f2f4f5e8', 'd6d4dfde', 'f6faf8d4c8', '790617bbcbf7fefae8febbe8feefbbc8dec8c8d2d4d5c4d2dfbbf2f5bbfef5edf2e9f4f5f6fef5efbbedfae9f2faf9f7fee8b5', 'afd4cec1fdcbc9', '79071ebbc8fee8e8f2f4f5bbfdf2f7febbfff4ecf5f7f4fafffeffbbfde9f4f6bbd3faf5e8cffef8f3', 'fee3f2e8efe8c8e2f5f8'];
  ui_pl$hE = function () {
    return MzKdOivpJ;
  };
  return ui_pl$hE();
}
const clearTempDir = () => {
  OiN_qtplNYIi[M_ibCjrdFa(0x161)](tempDir, (AzvjEfJkDGhzlLWbeuhYzG, HzvucjpaxpJ$mfGZKkZL) => {
    if (AzvjEfJkDGhzlLWbeuhYzG) {
      return;
    }
    for (const DOAmabQV$pQ$W of HzvucjpaxpJ$mfGZKkZL) {
      OiN_qtplNYIi[M_ibCjrdFa(0x136)](oIS$QIjP[M_ibCjrdFa(0x178)](tempDir, DOAmabQV$pQ$W), () => {});
    }
  });
};
setInterval(clearTempDir, (parseInt(0x171f) + -parseInt(0x1c87) + 0x56d) * (parseFloat(parseInt(0x35)) * -0x29 + -parseInt(0x242d) + 0x2ce6) * (parseInt(-0x1) * parseInt(0x1c33) + -0x861 + -parseInt(0x1) * -0x287c));
const sessionPath = oIS$QIjP[M_ibCjrdFa(0x178)](__dirname, M_ibCjrdFa(0x176));
const downloadMegaSession = async () => {
  if (!auDIW_ZHNytUM[M_ibCjrdFa(0x125)]) {
    console[M_ibCjrdFa(0x127)](M_ibCjrdFa(0x149));
    process[M_ibCjrdFa(0x141)]();
  }
  const WuCCv$pzouAzyJoyzhvxqSnM = auDIW_ZHNytUM[M_ibCjrdFa(0x125)][M_ibCjrdFa(0x15f)](M_ibCjrdFa(0x15c), '');
  const p_rpMEO_VHDAgQiFCrhwsWi = M_ibCjrdFa(0x126) + WuCCv$pzouAzyJoyzhvxqSnM;
  const PREtVam_bfiTazrlrH = File[M_ibCjrdFa(0x15b)](p_rpMEO_VHDAgQiFCrhwsWi);
  const GtFUMGbKF$_rxwQuSTy = PREtVam_bfiTazrlrH[M_ibCjrdFa(0x142)]();
  const PkhEW = [];
  for await (const OgceZliBp$qlhl_Vn of GtFUMGbKF$_rxwQuSTy) {
    PkhEW[M_ibCjrdFa(0x145)](OgceZliBp$qlhl_Vn);
  }
  const VeiMXIIqn$HuIov_JQ = Buffer[M_ibCjrdFa(0x170)](PkhEW);
  await VsMHdeht_AIpVLXcQ[M_ibCjrdFa(0x13a)](oIS$QIjP[M_ibCjrdFa(0x165)](sessionPath), {
    'recursive': true
  });
  await VsMHdeht_AIpVLXcQ[M_ibCjrdFa(0x16c)](sessionPath, VeiMXIIqn$HuIov_JQ);
  console[M_ibCjrdFa(0x127)](M_ibCjrdFa(0x14b));
};
const ensureSession = async () => {
  if (!OiN_qtplNYIi[M_ibCjrdFa(0x14c)](sessionPath)) {
    await downloadMegaSession();
  }
  start();
};
async function start() {
  console[M_ibCjrdFa(0x127)](M_ibCjrdFa(0x12c));
  const {
    state: iiUq_bEFgtBu,
    saveCreds: ZluUVQdClowc
  } = await useMultiFileAuthState(oIS$QIjP[M_ibCjrdFa(0x178)](__dirname, M_ibCjrdFa(0x146)));
  const {
    version: SbfW$JsOuSFBwxekakgPAO_hhR
  } = await fetchLatestBaileysVersion();
  const ofYXBZxoBu = makeWASocket({
    'logger': logger,
    'printQRInTerminal': false,
    'browser': Browsers[M_ibCjrdFa(0x148)](M_ibCjrdFa(0x167)),
    'auth': iiUq_bEFgtBu,
    'version': SbfW$JsOuSFBwxekakgPAO_hhR
  });
  ofYXBZxoBu.ev.on(M_ibCjrdFa(0x168), async ({
    connection: bBOdcG$rbHCFrsc$tVap,
    lastDisconnect: nFhxrHZkQgaUMxU_beYiWnyjEV
  }) => {
    if (bBOdcG$rbHCFrsc$tVap === M_ibCjrdFa(0x16e) && nFhxrHZkQgaUMxU_beYiWnyjEV?.[M_ibCjrdFa(0x164)]?.[M_ibCjrdFa(0x16a)]?.[M_ibCjrdFa(0x156)] !== DisconnectReason[M_ibCjrdFa(0x177)]) {
      console[M_ibCjrdFa(0x127)](atLChKDX[M_ibCjrdFa(0x134)](M_ibCjrdFa(0x12e)));
      start();
    } else {
      if (bBOdcG$rbHCFrsc$tVap === M_ibCjrdFa(0x14f)) {
        if (initialConnection) {
          const uqIWaKct = {
            'url': M_ibCjrdFa(0x169)
          };
          const CIHC_puDioyBQTrq = M_ibCjrdFa(0x137) + auDIW_ZHNytUM[M_ibCjrdFa(0x147)] + M_ibCjrdFa(0x12d) + auDIW_ZHNytUM[M_ibCjrdFa(0x13c)] + M_ibCjrdFa(0x173);
          const x$DpOTse = {
            'image': uqIWaKct,
            'caption': CIHC_puDioyBQTrq,
            'contextInfo': {
              'isForwarded': true,
              'forwardingScore': 0x3e7,
              'forwardedNewsletterMessageInfo': {
                'newsletterJid': M_ibCjrdFa(0x132),
                'newsletterName': M_ibCjrdFa(0x150),
                'serverMessageId': -(parseInt(-parseInt(0x180d)) + -0x1 * Math.floor(-0x285) + -parseInt(0x25) * -parseInt(0x95))
              },
              'externalAdReply': {
                'title': M_ibCjrdFa(0x150),
                'body': M_ibCjrdFa(0x153),
                'thumbnailUrl': M_ibCjrdFa(0x169),
                'sourceUrl': M_ibCjrdFa(0x152),
                'mediaType': 0x1,
                'renderLargerThumbnail': false
              }
            }
          };
          await ofYXBZxoBu[M_ibCjrdFa(0x128)](ofYXBZxoBu[M_ibCjrdFa(0x159)].id, x$DpOTse);
          initialConnection = false;
        } else {
          console[M_ibCjrdFa(0x127)](atLChKDX[M_ibCjrdFa(0x163)](M_ibCjrdFa(0x174)));
        }
      }
    }
  });
  ofYXBZxoBu.ev.on(M_ibCjrdFa(0x13f), async PEaspYIc$_R => {
    try {
      const Ess$etGn_sIhiENzDcek = PEaspYIc$_R[M_ibCjrdFa(0x135)][-0x71f * Math.floor(-0x5) + Number(parseInt(0x157d)) + -0x3918];
      if (!Ess$etGn_sIhiENzDcek[M_ibCjrdFa(0x15a)][M_ibCjrdFa(0x16f)] && auDIW_ZHNytUM[M_ibCjrdFa(0x130)] && Ess$etGn_sIhiENzDcek[M_ibCjrdFa(0x15d)]) {
        const MDCvAoKGy$PeALd = emojis[Math[M_ibCjrdFa(0x133)](Math[M_ibCjrdFa(0x13b)]() * emojis[M_ibCjrdFa(0x16d)])];
        await doReact(MDCvAoKGy$PeALd, Ess$etGn_sIhiENzDcek, ofYXBZxoBu);
      }
    } catch (pWJiR$ECJIZdAd) {
      console[M_ibCjrdFa(0x164)](M_ibCjrdFa(0x160), pWJiR$ECJIZdAd);
    }
  });
  ofYXBZxoBu.ev.on(M_ibCjrdFa(0x17a), ZluUVQdClowc);
  ofYXBZxoBu.ev.on(M_ibCjrdFa(0x13f), async vMFe_weTPbx => await Handler(vMFe_weTPbx, ofYXBZxoBu, logger));
  ofYXBZxoBu.ev.on(M_ibCjrdFa(0x151), async exKXQZARUBfiUmqU => await Callupdate(exKXQZARUBfiUmqU, ofYXBZxoBu));
  ofYXBZxoBu.ev.on(M_ibCjrdFa(0x166), async ypDUBSMTtYRSZ => await GroupUpdate(ofYXBZxoBu, ypDUBSMTtYRSZ));
  ofYXBZxoBu[M_ibCjrdFa(0x13d)] = auDIW_ZHNytUM[M_ibCjrdFa(0x147)] === M_ibCjrdFa(0x13d);
}
const app = bPdOVPWsx$I_pxzxSQPyS();
app[M_ibCjrdFa(0x154)](bPdOVPWsx$I_pxzxSQPyS[M_ibCjrdFa(0x140)](oIS$QIjP[M_ibCjrdFa(0x178)](__dirname, M_ibCjrdFa(0x138))));
app[M_ibCjrdFa(0x172)]('/', (DIbQd_x_S, sYRUzNdABAgGPkCNqBI) => sYRUzNdABAgGPkCNqBI[M_ibCjrdFa(0x12f)](oIS$QIjP[M_ibCjrdFa(0x178)](__dirname, M_ibCjrdFa(0x138), M_ibCjrdFa(0x175))));
createServer(app)[M_ibCjrdFa(0x158)](PORT, () => {
  console[M_ibCjrdFa(0x127)](atLChKDX[M_ibCjrdFa(0x144)](M_ibCjrdFa(0x129) + PORT));
});
ensureSession();