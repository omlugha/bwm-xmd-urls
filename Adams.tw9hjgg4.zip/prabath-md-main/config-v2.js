const DATABASE = "" // මෙතනට mongodb,mysql,postgresql or github token එකක් enter කරන්න මේ "" දෙක මැදට. (Enter a mongodb,mysql,postgresql or github token here between these two "".)
const BOT_NUMBER = "" // ඔයාගෙ whatsapp number එක. (your whatsapp number)
const SESSION_ID = "" // ඔයාගෙ session id එක මේකෙන් ගන්න - https://prabathmd-official.vercel.app


// ඉහත ඒව "" මැදට එකතු කරන්න වෙනත් කිසිම දෙයක් වෙනස් නොකරන්න ❌. (Add "" in the middle of the above and ❌ don't change anything else.)





const GITHUB_AUTH_TOKEN = DATABASE
module.exports = {
GITHUB_AUTH_TOKEN,
BOT_NUMBER,
SESSION_ID
}
