<br>

## PRABATH-MD 👨‍💻 🇱🇰 - A Javascript WhatsApp User Bot

<br>

🔮 `The main goal of creating this bot is to fully leverage WhatsApp and simplify its functionality.`

<br>
 
  <p align="center">  
  <a href="https://telegra.ph/file/1743544c222ffd613c219.jpg">
    <img alt="prabath-md" height="300" src="https://telegra.ph/file/1743544c222ffd613c219.jpg">
    
  
  </a>
</p>  


<br>
<br>

💡 `This bot is created to download and find various things quickly, logo, photo edit and many other features. This bot is created using` **[Baileys](https://github.com/WhiskeySockets/Baileys)**


<br>
<br>

<a href="https://whatsapp.com/channel/0029Va5dJKyJpe8oqDXUjI3x"><img src="https://img.shields.io/badge/%F0%9F%8E%89%20Join%20Our%20WhatsApp%20Channel-black" alt="📎 Join Our WhatsApp Channel" width="300"></a>

<br>

---

<a href="https://prabathmd-official.vercel.app/"><img src="https://img.shields.io/badge/DEPLOY-greeen" alt="Create prabath-md bot" width="150"></a>

<br>

[![FORK PRABATH-MD](https://img.shields.io/badge/FORK%20-PRABATH%20MD-white)](https://gitlab.com/prabathLK/prabath-md/-/forks/new)

 ---
 
<a href="https://prabath-md-terms-and-rules.vercel.app/"><img src="https://img.shields.io/badge/Read%20Our%20Terms%20and%20Conditions-red" alt="DEPLOY" width="270"></a>

---

<a href="https://www.buymeacoffee.com/PrabathKumara" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

---

## 👑 **`PRABATH-MD BOT OWNERS,`** 👑


   <a href="https://github.com/prabathLK/"><img src="https://avatars.githubusercontent.com/u/106251140?v=4" width=80 height=80></a>   

---

|**[`Prabath Kumara`](https://github.com/prabathLK)**|

---

<a href="https://github.com/SACHIBOT"><img src="https://avatars.githubusercontent.com/u/91013948?v=4" width=80 height=80></a> 

|**[`Sachintha Rashan`](https://github.com/SACHIBOT)**|

---

<br>
<br>
<br>
<br>
<br>

`Released date:- 2023.08.24`
<br>
`latest updated date:- 2025.07.07`