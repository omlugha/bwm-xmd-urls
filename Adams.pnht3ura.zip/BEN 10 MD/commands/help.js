const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message, channelLink) {
  const helpMessage = `
*├▢🚘${settings.botName || '𝗕𝗘𝗡 10 𝗠𝗗'} 
 *├▢🔰𝗩𝗲𝗿𝘀𝗶𝗼𝗻 ✞︎ ${settings.version || '3.0.0'}*
*├▢🎖️𝗣𝗹𝘂𝗴𝗶𝗻𝘀 ✞︎ ${settings.botOwner || '103'}
*├▢👤𝗖𝗿𝗲𝗮𝘁𝗼𝗿 ✞︎ ${global.ytch}
*├▢⚡𝗣𝗿𝗲𝗳𝗶𝘅   ✞︎ [ . ]
*├▢✅𝗦𝘁𝗮𝘁𝘂𝘀  ︎✞︎𝗢𝗻𝗹𝗶𝗻𝗲

 *╭───⬡ 𝗦𝗘𝗟𝗘𝗖𝗧 𝗠𝗘𝗡𝗨 ⬡───*:*
 ├
*├▢1️⃣. 🤝 𝗚𝗲𝗻𝗲𝗿𝗮𝗹  
*├▢2️⃣. 👑 𝗔𝗱𝗺𝗶𝗻   
*├▢3️⃣. 👤 𝗢𝘄𝗻𝗲𝗿   
*├▢4️⃣. 🌄 𝗜𝗺𝗮𝗴𝗲   
*├▢5️⃣. 🎮 𝗚𝗮𝗺𝗲    
*├▢6️⃣. 🍥 𝗔𝗶/𝗦𝗲𝗮𝗿𝗰𝗵         
*├▢7️⃣. 😂 𝗙𝘂𝗻      
*├▢8️⃣. 💤 𝗧𝗲𝘅𝘁𝗺𝗮𝗸𝗲𝗿     
*├▢9️⃣. 🎬 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱      
*├▢🔟. 📚 𝗚𝗶𝘁𝗵𝘂𝗯     

★╰──────────────────
*⚽𝙋𝙊𝙒𝙀𝙍𝙀𝘿 𝘽𝙔 𝙎𝙉𝙊𝙒𝘽𝙄𝙍𝘿:* ${channelLink}
`;


  try {
    const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
    const audioPath = path.join(__dirname, '../assets/welcome.mp3');

    const buttons = [
      { buttonId: '.general', buttonText: { displayText: 'General Commands' }, type:1 },
      { buttonId: '.admin', buttonText: { displayText: 'Admin Commands' }, type:1 },
      { buttonId: '.owner', buttonText: { displayText: 'Owner Commands' }, type:1 },
      { buttonId: '.image', buttonText: { displayText: 'Image/Sticker Commands' }, type:1 },
      { buttonId: '.game', buttonText: { displayText: 'Game Commands' }, type:1 },
      { buttonId: '.ai', buttonText: { displayText: 'AI Commands' }, type:1 },
      { buttonId: '.fun', buttonText: { displayText: 'Fun Commands' }, type:1 },
      { buttonId: '.textmaker', buttonText: { displayText: 'Textmaker' }, type:1 },
      { buttonId: '.downloader', buttonText: { displayText: 'Downloader' }, type:1 },
      { buttonId: '.github', buttonText: { displayText: 'Github Commands' }, type:1 },
    ];

    const buttonMessage = {
      image: fs.existsSync(imagePath) ? { url: imagePath } : null,
      caption: helpMessage,
      footer: 'Select a category to view commands',
      buttons: buttons,
      headerType:4,
      contextInfo: {
        forwardingScore:1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363399707841760@newsletter',
          newsletterName: '𝗕𝗘𝗡 10 𝗠𝗗',
          serverMessageId: -1,
        },
      },
    };

    await sock.sendMessage(chatId, buttonMessage, { quoted: message });

    // Send audio message
    if (fs.existsSync(audioPath)) {
      await sock.sendMessage(chatId, { audio: { url: audioPath }, mimetype: 'audio/mp4' }, { quoted: message });
    }
  } catch (error) {
    console.error('Error in help command:', error);
    await sock.sendMessage(chatId, { text: helpMessage });
  }
}

module.exports = helpCommand;
